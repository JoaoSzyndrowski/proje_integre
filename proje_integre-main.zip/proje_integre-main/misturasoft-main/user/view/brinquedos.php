<?php
// sem isso, nem eu funciono
include("conexao.php");

$limite = 5;
$pagina = isset($_GET['pagina']) ? (int)$_GET['pagina'] : 1;
$offset = ($pagina - 1) * $limite;

// Recupera o termo de pesquisa, se existir
$pesquisa = isset($_GET['pesquisa']) ? $_GET['pesquisa'] : '';

// Filtra os produtos pela pesquisa
if ($pesquisa) {
    $sql = "SELECT * FROM produto WHERE nome LIKE ? LIMIT $limite OFFSET $offset";
    $stmt = mysqli_prepare($conn, $sql);
    $search_term = "%" . $pesquisa . "%";
    mysqli_stmt_bind_param($stmt, 's', $search_term);
    mysqli_stmt_execute($stmt);
    $resultado = mysqli_stmt_get_result($stmt);
} else {
    $sql = "SELECT * FROM produto LIMIT $limite OFFSET $offset";
    $resultado = mysqli_query($conn, $sql);
}

if ($resultado) {
    $produtos = mysqli_fetch_all($resultado, MYSQLI_ASSOC);
} else {
    $produtos = [];
}

// Conta total de produtos (com ou sem pesquisa)
$sql_total = "SELECT COUNT(*) AS total FROM produto WHERE nome LIKE ?";
$stmt_total = mysqli_prepare($conn, $sql_total);
mysqli_stmt_bind_param($stmt_total, 's', $search_term);
mysqli_stmt_execute($stmt_total);
$resultado_total = mysqli_stmt_get_result($stmt_total);
$total_produtos = mysqli_fetch_assoc($resultado_total)['total'];

mysqli_close($conn);
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap"
        rel="stylesheet">
    <link rel="stylesheet" href="style.css">
    <title>Brinquedos - MisturaSoft</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: Arial, sans-serif;
        }

        body {
            background-color: #EFE9E9;
            color: #333;
        }

        .container {
            width: 90%;
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }

        header {
    padding: 40px 4%;
    display: flex;
    justify-content: space-between;
    align-items: center;
    position: relative;
}

header > .interface {
    display: flex;
    align-items: center;
    justify-content: center;
    flex-grow: 1; /* Garante que os links sejam centralizados */
    position: relative;
}

header .logo {
    position: absolute;
    left: 0;
    top: 50%;
    transform: translateY(-50%);
}

header nav ul {
    list-style-type: none;
    display: flex;
    gap: 40px;
}

header nav ul li {
    display: inline-block;
}

header a {
    color: #5c5c5c;
    text-decoration: none;
    transition: 0.2s;
    font-size: 18px;
    font-weight: black;
}

header a:hover {
    color: #000;
    transform: scale(1.05);
}

        .search-bar {
            display: flex;
            justify-content: right;
            margin: 20px 0;
        }

        .search-bar form {
            display: flex;
            align-items: center;
            gap: 5px;
        }

        .search-bar input {
            padding: 10px;
            font-size: 16px;
            border: 1px solid #ccc;
            border-radius: 5px 0 0 5px;
            width: 100%;
            max-width: 400px;
        }

        .search-bar button {
            padding: 10px 20px;
            font-size: 16px;
            background-color: #6fae42;
            color: white;
            border: 1px solid #ccc;
            border-left: none;
            border-radius: 0 5px 5px 0;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        .search-bar button:hover {
            background-color: #5b8d36;
        }

        .products {
            display: flex;
            flex-direction: column;
            gap: 20px;
        }

        .product-card {
            display: flex;
            align-items: center;
            padding: 20px;
            background-color: #ffffff;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        .product-image {
            width: 100px;
            height: 100px;
            border-radius: 10px;
            overflow: hidden;
            margin-right: 20px;
        }

        .product-image img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .product-info {
            flex: 1;
        }

        .product-info h3 {
            font-size: 18px;
            margin-bottom: 5px;
        }

        .product-info p {
            font-size: 14px;
            color: #666;
            margin-bottom: 10px;
        }

        .product-card button {
            background-color: #6fae42;
            color: white;
            border: none;
            padding: 10px 20px;
            font-size: 16px;
            cursor: pointer;
            border-radius: 5px;
            transition: background-color 0.3s;
        }

        .product-card button:hover {
            background-color: #5b8d36;
        }

        .load-more {
            display: block;
            width: 100%;
            padding: 10px;
            background-color: #6fae42;
            color: white;
            text-align: center;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            cursor: pointer;
        }

        .load-more:hover {
            background-color: #5b8d36;
        }

        @media (max-width: 768px) {
            header {
                flex-direction: column;
                text-align: center;
            }

            nav ul {
                flex-direction: column;
                gap: 10px;
            }

            .product-card {
                flex-direction: column;
                align-items: center;
                text-align: center;
            }

            .product-image {
                margin-right: 0;
                margin-bottom: 15px;
            }
        }
    </style>
</head>
<body>
    <div class="container">
    <header>
        <div class="interface">
            <div class="logo">
                    <img src="/proje_integre-main/misturasoft-main/user/imagens/logo.png" alt="" height="100" width="230">
                </a>
            </div>
            <nav class="menu-desktop">
                <ul>
                    <li><a href="/proje_integre-main/misturasoft-main/user/index.php">Início </a></li>
                    <li><a href="">Brinquedos </a></li>
                    <li><a href="/proje_integre-main/misturasoft-main/user/view/sobre.php">Sobre </a></li>
                </ul>
            </nav>
        </div>
    </header>
        
        <div class="search-bar">
            <form action="" method="GET">
                <input type="text" name="pesquisa" placeholder="Pesquisar brinquedo" value="<?php echo htmlspecialchars($pesquisa); ?>">
                <button type="submit">🔍</button>
            </form>
        </div>

        <h2>Brinquedos</h2>
        
        <div class="products">
            <?php foreach ($produtos as $produto): ?>
                <a href="ag_brinq.php?id=<?php echo urlencode($produto['id_produto']); ?>" class="product-link">
                    <div class="product-card" id="product-<?php echo $produto['id_produto']; ?>">
                        <div class="product-image">
                            <img src="imagens/<?php echo htmlspecialchars($produto['img']) ?: 'default.jpg'; ?>" alt="<?php echo htmlspecialchars($produto['nome']); ?>">
                        </div>
                        <div class="product-info">
                            <h3><?php echo htmlspecialchars($produto['nome']); ?></h3>
                            <p><?php echo htmlspecialchars(substr($produto['descricao'], 0, 100)); ?>...</p>
                        </div>
                        <button>Reservar</button>
                    </div>
                </a>
            <?php endforeach; ?>
        </div>

        <?php if ($pagina * $limite < $total_produtos): ?>
            <div style="text-align: center; margin-top: 20px;">
                <a href="?pagina=<?php echo $pagina + 1; ?>&pesquisa=<?php echo urlencode($pesquisa); ?>">
                    <button class="load-more">Carregar Mais</button>
                </a>
            </div>
        <?php endif; ?>
    </div>
</body>
</html>

