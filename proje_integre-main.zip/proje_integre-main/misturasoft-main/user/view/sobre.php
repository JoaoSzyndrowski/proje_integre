<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- fonte do google -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap"
        rel="stylesheet">
    <!-- fim da fonte -->
    <!-- icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <!-- fim icons-->
    <link rel="stylesheet" href="style.css">
    <title>MISTURA FINA FESTAS</title>
    <style>header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 20px 0;
        }

        header {
    padding: 40px 4%;
    display: flex;
    justify-content: space-between;
    align-items: center;
    position: relative;
}

header > .interface {
    display: flex;
    align-items: center;
    justify-content: center;
    flex-grow: 1; /* Garante que os links sejam centralizados */
    position: relative;
}

header .logo {
    position: absolute;
    left: 0;
    top: 50%;
    transform: translateY(-50%);
}

header nav ul {
    list-style-type: none;
    display: flex;
    gap: 40px;
}

header nav ul li {
    display: inline-block;
}

header a {
    color: #5c5c5c;
    text-decoration: none;
    transition: 0.2s;
    font-size: 18px;
    font-weight: black;
}

header a:hover {
    color: #000;
    transform: scale(1.05);
}
    </style>
</head>
<body>
<header>
        <div class="interface">
            <div class="logo">
                    <img src="/proje_integre-main/misturasoft-main/user/imagens/logo.png" alt="" height="100" width="230">
                </a>
            </div>
            <nav class="menu-desktop">
                <ul>
                    <li><a href="/proje_integre-main/misturasoft-main/user/index.php">Início </a></li>
                    <li><a href="/proje_integre-main/misturasoft-main/user/view/brinquedos.php">Brinquedos </a></li>
                    <li><a href="">Sobre </a></li>
                </ul>
            </nav>
        </div>
    </header>
    <main>
        <section class="topo-do-site">
            <div class="interface">
                <div class="flex">
                    <div class="txt-topo-site">
                        <h1>
                            Sobre-nós<span>!</span>
                        </h1>
                        <p>Fundada há 7 anos, nossa empresa nasceu em Cocal do Sul com o propósito de levar alegria e diversão para crianças e famílias. Especializada em brinquedos de alta qualidade, oferecemos um mix de opções que encantam pela criatividade e segurança, proporcionando momentos únicos de brincadeira.

Com o compromisso de atender às necessidades de nossos clientes, nos dedicamos a trazer inovação e sorrisos em cada produto. Ao longo dos anos, nos tornamos parte das histórias de muitas famílias da região, sempre guiados pelos valores de confiança, dedicação e paixão pelo que fazemos.

Seguimos crescendo e levando nossa missão adiante: transformar brincadeiras em memórias inesquecíveis!</p>    
                    </div>
                </div>
</section>
</body>
</html>
<footer>
            <div class="interface">
                <div class="line-footer">
                    <div class="flex">
                    </div>
                </div>

                <div class="line-footer borda" />

                <div class="btn-btn">
                    <div class="btn-social">
                        <a href="">
                            <button>
                                <i
                                    class="bi bi-instagram">
                                </i>
                            </button>
                        </a>
                        <a href=""><button><i
                                    class="bi bi-facebook"></i></button></a>
                        <a href=""><button><i
                                    class="bi bi-whatsapp"></i></button></a>
                        <a href=""><button><i class="bi bi-envelope"></i></button></a>
                    </div>
                </div>
                <img src="/misturasoft-main/imagens/logo.png" alt="logo" height="100" width="230">

            </div>
        </footer>