<?php
include("../control/conexao.php");
session_start();
$idUser = $_SESSION['id_user'];

$sql = "
    SELECT 
        agendamento.id_agenda, 
        agendamento.data, 
        produto.nome AS nome_produto,
        agendamento.horainicio, 
        agendamento.horafim, 
        cliente.nome AS nome_cliente,
        agendamento.sts
    FROM 
        agendamento
    INNER JOIN 
        produto ON agendamento.id_produto = produto.id_produto
    INNER JOIN 
        cliente ON agendamento.id_cliente = cliente.id_cliente
    WHERE 
        agendamento.id_cliente = ?";

$stmt = $conn->prepare($sql);

if (!$stmt) {
    die("Erro ao preparar a consulta: " . $conn->error);
}

$stmt->bind_param("i", $idUser);
$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Agendamentos</title>
    <style>
        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background-color: #f3f3f3;
        }

        .container {
            max-width: 900px;
            margin: 50px auto;
            background-color: #ffffff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
        }

        h1 {
            text-align: center;
            color: #333;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        table th, table td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: center;
        }

        table th {
            background-color: #65b032;
            color: white;
        }

        a {
            text-decoration: none;
            color: #4a8b28;
        }

        a:hover {
            text-decoration: underline;
        }

        .logout {
            display: flex;
            justify-content: flex-end;
            margin-top: 20px;
        }

        .logout button {
            background-color: #4a8b28;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            transition: background-color 0.3s;
        }

        .logout button:hover {
            background-color: #3c7123;
        }
        .logout {
    display: flex;           /* Ativa o flexbox */
    justify-content: space-between; /* Espaça os itens pelos lados */
    align-items: center;     /* Alinha verticalmente no centro */
    padding: 10px;           /* Espaço interno para estética */
}

button {
    padding: 10px 20px;      /* Tamanho do botão */
    font-size: 16px;         /* Tamanho do texto */
    background-color: #007BFF; /* Cor de fundo */
    color: white;            /* Cor do texto */
    border: none;            /* Remove bordas */
    border-radius: 5px;      /* Bordas arredondadas */
    cursor: pointer;         /* Cursor de mão ao passar */
    transition: background-color 0.3s ease; /* Efeito suave no hover */
}

button:hover {
    background-color: #0056b3; /* Muda a cor no hover */
}

a {
    text-decoration: none;   /* Remove sublinhado */
}

    </style>
</head>
<body>
    <div class="container">
        <h1>Meus Agendamentos</h1>
        <table>
            <thead>
                <tr>
                    <th>ID Agenda</th>
                    <th>Data</th>
                    <th>Produto</th>
                    <th>Hora Início</th>
                    <th>Hora Fim</th>
                    <th>Cliente</th>
                    <th>Status</th>
                    <th>Editar</th>
                    <th>Excluir</th>
                </tr>
            </thead>
            <tbody>
                <?php
                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        echo "<tr>";
                        echo "<td>" . htmlspecialchars($row['id_agenda']) . "</td>";
                        echo "<td>" . htmlspecialchars($row['data']) . "</td>";
                        echo "<td>" . htmlspecialchars($row['nome_produto']) . "</td>";
                        echo "<td>" . htmlspecialchars($row['horainicio']) . "</td>";
                        echo "<td>" . htmlspecialchars($row['horafim']) . "</td>";
                        echo "<td>" . htmlspecialchars($row['nome_cliente']) . "</td>";
                        echo "<td>" . htmlspecialchars($row['sts']) . "</td>";
                        echo "<td><a href='#' onclick='alert(\"Entre em contato com nossos colaboradores pelo WhatsApp 48 99661-8098 e informe seu ID de Agendamento: " . $row['id_agenda'] . "\");'>Editar</a></td>";
                        echo "<td><a href='#' onclick='alert(\"Entre em contato com nossos colaboradores pelo WhatsApp 48 99661-8098 e informe seu ID de Agendamento: " . $row['id_agenda'] . "\");'>Excluir</a></td>";
                        echo "</tr>";
                    }
                } else {
                    echo "<tr><td colspan='9'>Nenhum agendamento encontrado.</td></tr>";
                }
                ?>
            </tbody>
        </table>

        <div class="logout">
            <a href="../index.php">
            <button>Voltar</button>
            </a>
            <a href="../index.php" onclick="logout();">
    <button>Logout</button>
</a>

<script>
    function logout() {
        <?php
session_start();

if(isset($_SESSION)){
    session_destroy();
}
if(session_destroy()){
    echo "sessoa destroua";
}


?>// Adicione o código para destruir a sessão ou realizar o logout aqui
        // Por exemplo, se estiver usando PHP:
        // window.location = 'logout.php'; // para processar o logout no servidor
    }
</script>
        </div>
    </div>
</body>
</html>

