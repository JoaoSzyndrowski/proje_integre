<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Agendamento</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            color: #333;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }

        .form-container {
            background: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
            max-width: 400px;
            width: 100%;
        }

        h2 {
            text-align: center;
            color: #2d572c;
            margin-bottom: 20px;
        }

        label {
            display: block;
            margin: 10px 0 5px;
            font-weight: bold;
            color: #555;
        }

        input[type="date"],
        input[type="time"],
        select {
            width: calc(100% - 20px);
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 16px;
            box-sizing: border-box;
        }

        input[type="submit"] {
            background-color: #2d572c;
            color: white;
            font-size: 16px;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s;
            width: 100%;
        }

        input[type="submit"]:hover {
            background-color: #1e3c1c;
        }

        .btn-voltar {
            margin-top: 15px;
            display: block;
            background-color: #ccc;
            color: #333;
            text-align: center;
            font-size: 16px;
            padding: 10px 20px;
            text-decoration: none;
            border-radius: 5px;
            transition: background-color 0.3s;
        }

        .btn-voltar:hover {
            background-color: #999;
            color: #fff;
        }
    </style>
</head>
<body>
    <div class="form-container">
        <h2>Editar Agendamento</h2>
        <form action="" method="post">
            <label for="data">Data:</label>
            <input type="date" name="data" id="data" value="<?php echo $data; ?>" required>

            <label for="hora_inicio">Hora Início:</label>
            <input type="time" name="hora_inicio" id="hora_inicio" value="<?php echo $hora_inicio; ?>" required>

            <label for="hora_fim">Hora Fim:</label>
            <input type="time" name="hora_fim" id="hora_fim" value="<?php echo $hora_fim; ?>" required>

           

            <input type="submit" value="Atualizar">
        </form>
        <a href="javascript:history.back()" class="btn-voltar">Voltar</a>
    </div>
</body>
</html>


