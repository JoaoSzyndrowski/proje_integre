<?php
include("conexao.php");

if (isset($_GET['id'])) {
    $id_produto = $_GET['id'];
    $sql = "SELECT * FROM produto WHERE id_produto = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id_produto);
    $stmt->execute();
    $result = $stmt->get_result();
    $produto = $result->fetch_assoc();

    if (!$produto) {
        echo "Produto não encontrado.";
        exit;
    }

    if (isset($_POST['atualizar'])) {
        $nome = $_POST['nome'];
        $preco = $_POST['preco'];
        $descricao = $_POST['descricao'];
        $tamanho = $_POST['tamanho'];
        $faixa_etaria = $_POST['faixa_etaria'];
        $status = $_POST['status'];

        $update_sql = "UPDATE produto SET nome = ?, preco = ?, descricao = ?, tamanho = ?, faixa_etaria = ?, status = ? WHERE id_produto = ?";
        $update_stmt = $conn->prepare($update_sql);
        $update_stmt->bind_param("ssssssi", $nome, $preco, $descricao, $tamanho, $faixa_etaria, $status, $id_produto);

        if ($update_stmt->execute()) {
            echo "<script type='text/javascript'>
                alert('Alteração feita com sucesso!');
                window.location.href = '/proje_integre-main/misturasoft-main/admin/view/brinquedo.php';
            </script>";
            exit;
        } else {
            echo "Erro ao atualizar produto.";
        }
    }
} else {
    echo "ID não fornecido.";
    exit;
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Produto</title>
    <link rel="stylesheet" href="../../styles/style.css">
    <style>
        body {
            background-color: #EFE9E9;
            font-family: Arial, sans-serif;
            color: #333;
            margin: 0;
            padding: 0;
        }

        .container {
            max-width: 800px;
            margin: 50px auto;
            padding: 20px;
            background: #FFF;
            border-radius: 8px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }

        h1 {
            text-align: center;
            margin-bottom: 20px;
        }

        form {
            display: flex;
            flex-direction: column;
            gap: 15px;
        }

        label {
            font-weight: bold;
        }

        input, textarea, select, button {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 16px;
        }

        button {
            background-color: #6fae42;
            color: #fff;
            border: none;
            cursor: pointer;
        }

        button:hover {
            background-color: #5b8d36;
        }

        .form-actions {
            display: flex;
            justify-content: space-between;
        }

        .form-actions a {
            text-decoration: none;
            padding: 10px 20px;
            background-color: #ccc;
            color: #333;
            border-radius: 5px;
            transition: background-color 0.3s;
        }

        .form-actions a:hover {
            background-color: #bbb;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Editar Produto</h1>
        <form method="POST">
            <label for="nome">Nome:</label>
            <input type="text" id="nome" name="nome" value="<?php echo htmlspecialchars($produto['nome']); ?>" required>

            <label for="preco">Preço:</label>
            <input type="text" id="preco" name="preco" value="<?php echo htmlspecialchars($produto['preco']); ?>" required>

            <label for="descricao">Descrição:</label>
            <textarea id="descricao" name="descricao" rows="5" required><?php echo htmlspecialchars($produto['descricao']); ?></textarea>

            <label for="tamanho">Tamanho:</label>
            <input type="text" id="tamanho" name="tamanho" value="<?php echo htmlspecialchars($produto['tamanho']); ?>" required>

            <label for="faixa_etaria">Faixa Etária:</label>
            <input type="text" id="faixa_etaria" name="faixa_etaria" value="<?php echo htmlspecialchars($produto['faixa_etaria']); ?>" required>

            <label for="status">Status:</label>
            <select id="status" name="status" required>
                <option value="ativo" <?php if ($produto['status'] == 'ativo') echo 'selected'; ?>>Disponível</option>
                <option value="inativo" <?php if ($produto['status'] == 'inativo') echo 'selected'; ?>>Indisponível</option>
            </select>

            <div class="form-actions">
                <button type="submit" name="atualizar">Atualizar Produto</button>
                <a href="/proje_integre-main/misturasoft-main/admin/view/brinquedo.php">Cancelar</a>
            </div>
        </form>
    </div>
</body>
</html>

