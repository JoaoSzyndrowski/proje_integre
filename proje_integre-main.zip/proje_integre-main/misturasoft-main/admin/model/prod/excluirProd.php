<?php
include("conexao.php");

if (isset($_GET['id'])) {

    $id_produto = $_GET['id'];
    $sql = "SELECT * FROM produto WHERE id_produto = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id_produto);
    $stmt->execute();
    $result = $stmt->get_result();
    $produto = $result->fetch_assoc();

    if (!$produto) {
        echo "Produto não encontrado.";
        exit;
    }

    if (isset($_POST['confirmar'])) {
        $delete_sql = "DELETE FROM produto WHERE id_produto = ?";
        $delete_stmt = $conn->prepare($delete_sql);
        $delete_stmt->bind_param("i", $id_produto);
        
        if ($delete_stmt->execute()) {
            sleep(5);
            echo "<script type='text/javascript'>
            alert('Produto excluído com sucesso!');
            window.location.href = '/proje_integre-main/misturasoft-main/admin/view/brinquedo.php';
            </script>";
            exit;
        } else {
            echo "Erro ao excluir produto.";
        }
    }
} else {
    echo "ID não fornecido.";
    exit;
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Excluir Produto</title>
    <style>
        /* Estilização geral */
        body {
            margin: 0;
            padding: 0;
            font-family: Arial, sans-serif;
            background-color: #f9f9f9;
            color: #333;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
        }

        .container {
            width: 100%;
            max-width: 500px;
            background: #fff;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            padding: 20px;
            text-align: center;
        }

        h1 {
            font-size: 24px;
            margin-bottom: 20px;
            color: #e74c3c;
        }

        p {
            margin: 10px 0;
            font-size: 16px;
            line-height: 1.4;
        }

        .form-actions {
            display: flex;
            justify-content: space-between;
            margin-top: 20px;
        }

        button, a {
            text-decoration: none;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            cursor: pointer;
        }

        button {
            background-color: #e74c3c; /* Vermelho */
            color: white;
            transition: background-color 0.3s ease;
        }

        button:hover {
            background-color: #c0392b;
        }

        a {
            background-color: #7f8c8d; /* Cinza */
            color: white;
            transition: background-color 0.3s ease;
            display: inline-block;
        }

        a:hover {
            background-color: #616a6b;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Deseja excluir o produto?</h1>
        <div class="product-details">
            <p><strong>ID:</strong> <?php echo htmlspecialchars($produto['id_produto']); ?></p>
            <p><strong>Nome:</strong> <?php echo htmlspecialchars($produto['nome']); ?></p>
            <p><strong>Descrição:</strong> <?php echo htmlspecialchars($produto['descricao']); ?></p>
            <p><strong>Preço:</strong> R$ <?php echo htmlspecialchars($produto['preco']); ?></p>
        </div>
        <form method="POST">
            <div class="form-actions">
                <button type="submit" name="confirmar">Confirmar Exclusão</button>
                <a href="/proje_integre-main/misturasoft-main/admin/view/brinquedo.php">Cancelar</a>
            </div>
        </form>
    </div>
</body>
</html>

