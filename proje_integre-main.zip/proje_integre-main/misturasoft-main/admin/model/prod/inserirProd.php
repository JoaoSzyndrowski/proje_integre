<?php
include("conexao.php");

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $preco = $_POST['preco'];
    $nome = $_POST['nome'];
    $descricao = $_POST['descricao'];
    $tamanho = $_POST['tamanho'];
    $faixa_etaria = $_POST['faixa_etaria'];
    $status = $_POST['status'];

    $sql = "INSERT INTO produto (preco, nome, descricao, tamanho, faixa_etaria, status)
            VALUES (?, ?, ?, ?, ?, ?)";
    if ($stmt = $conn->prepare($sql)) {
        $stmt->bind_param("ssssss", $preco, $nome, $descricao, $tamanho, $faixa_etaria, $status);
        if ($stmt->execute()) {
            echo "Produto inserido com sucesso!";
            header("Location: ../../view/brinquedo.php"); // Redireciona de volta à página principal após inserção
            exit;
        } else {
            echo "Erro ao inserir produto: " . $stmt->error;
        }
        $stmt->close();
    } else {
        echo "Erro ao preparar a consulta: " . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Adicionar Produto - MisturaSoft</title>
    <link rel="stylesheet" href="style.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: Arial, sans-serif;
        }

        body {
            background-color: #EFE9E9;
            color: #333;
        }

        .container {
            width: 90%;
            max-width: 600px;
            margin: 50px auto;
            background-color: #ffffff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        h2 {
            text-align: center;
            margin-bottom: 20px;
            color: #6fae42;
        }

        form {
            display: flex;
            flex-direction: column;
            gap: 15px;
        }

        label {
            font-weight: bold;
            margin-bottom: 5px;
        }

        input, select, textarea, button {
            padding: 10px;
            font-size: 16px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        textarea {
            resize: vertical;
            height: 100px;
        }

        button {
            background-color: #6fae42;
            color: white;
            border: none;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        button:hover {
            background-color: #5b8d36;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Adicionar Novo Produto</h2>
        <form action="inserirProd.php" method="POST">
            <label for="preco">Preço:</label>
            <input type="text" id="preco" name="preco" required>

            <label for="nome">Nome:</label>
            <input type="text" id="nome" name="nome" required>

            <label for="descricao">Descrição:</label>
            <textarea id="descricao" name="descricao" required></textarea>

            <label for="tamanho">Tamanho:</label>
            <select id="tamanho" name="tamanho">
                <option value="1 metro">1 metro</option>
                <option value="2 metros">2 metros</option>
                <option value="3 metros">3 metros</option>
                <option value="4 metros">4 metros</option>
                <option value="5 metros">5 metros</option>
                <option value="6 metros">6 metros</option>
                <option value="7 metros">7 metros</option>
                <option value="8 metros">8 metros</option>
                <option value="9 metros">9 metros</option>
                <option value="10 metros">10 metros</option>
            </select>
            
            <label for="faixa_etaria">Faixa Etária:</label>
            <select id="faixa_etaria" name="faixa_etaria">
                <option value="Adulto">Adulto</option>
                <option value="Criança">Criança</option>
            </select>
            
            <label for="status">Status:</label>
            <select id="status" name="status" required>
                <option value="dips">Disponível</option>
                <option value="indisp">Indisponível</option>
            </select>

            <button type="submit">Adicionar Produto</button>
        </form>
    </div>
</body>
</html>
        
