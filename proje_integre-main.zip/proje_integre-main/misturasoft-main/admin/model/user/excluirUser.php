<?php
include("conexao.php");

if ($conn->connect_error) {
    die("Erro de conexão: " . $conn->connect_error);
}
if (isset($_GET['id'])) {
    $id_usuario = $_GET['id'];
    $sql = "SELECT id_usuario, nome, email FROM usuario WHERE id_usuario = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id_usuario);
    $stmt->execute();
    $result = $stmt->get_result();
    $usuario = $result->fetch_assoc();

    if (!$usuario) {
        echo "Usuário não encontrado.";
        exit;
    }
    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        $delete_usuario_sql = "DELETE FROM usuario WHERE id_usuario = ?";
        $delete_usuario_stmt = $conn->prepare($delete_usuario_sql);

        if ($delete_usuario_stmt === false) {
            die("Erro na preparação da consulta de exclusão de usuário: " . $conn->error);
        }

        $delete_usuario_stmt->bind_param("i", $id_usuario);
        if ($delete_usuario_stmt->execute()) {
            echo "<script type='text/javascript'>
                    alert('Usuário excluído com sucesso!');
                    window.location.href = '/proje_integre-main/misturasoft-main/admin/view/user.php'; 
                  </script>";
            exit;
        } else {
            echo "Erro ao excluir o usuário: " . $conn->error;
        }
    }
} else {
    echo "ID do usuário não foi fornecido.";
    exit;
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Excluir Usuário</title>
    <style>
        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background-color: #f3f3f3;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
        }

        .container {
            background-color: #65b032;
            padding: 20px 40px;
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
            text-align: center;
            color: white;
            width: 400px;
        }

        h1 {
            margin-bottom: 20px;
        }

        p {
            font-size: 16px;
            margin-bottom: 10px;
        }

        form {
            margin-top: 20px;
        }

        input[type="submit"],
        a {
            background-color: #4a8b28;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            text-decoration: none;
            transition: background-color 0.3s;
            margin-right: 10px;
        }

        input[type="submit"]:hover,
        a:hover {
            background-color: #3c7123;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Deseja excluir o usuário?</h1>
        <p><strong>ID:</strong> <?php echo htmlspecialchars($usuario['id_usuario']); ?></p>
        <p><strong>Nome:</strong> <?php echo htmlspecialchars($usuario['nome']); ?></p>
        <p><strong>Email:</strong> <?php echo htmlspecialchars($usuario['email']); ?></p>

        <form method="POST">
            <input type="submit" value="Confirmar Exclusão">
            <a href="/proje_integre-main/misturasoft-main/admin/view/user.php">Cancelar</a>
        </form>
    </div>
</body>
</html>

