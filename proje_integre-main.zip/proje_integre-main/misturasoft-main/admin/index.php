<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Administração</title>
    <style>
        /* Estilo para a página */
        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background-color: #f3f3f3;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        /* Caixa central */
        .container {
            background-color: #65b032;
            padding: 20px 40px;
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
            text-align: center;
            color: white;
            max-width: 400px;
        }

        /* Título */
        .container h1 {
            font-size: 20px;
            margin-bottom: 20px;
        }

        /* Links */
        .container a {
            display: block;
            font-size: 16px;
            color: white;
            text-decoration: none;
            margin: 10px 0;
        }

        /* Links com hover */
        .container a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>PÁGINA DE ADMINISTRAÇÃO</h1>
        <a href="view/user.php">ADMINISTRAR USUÁRIOS</a>
        <a href="view/agendamento.php">ADMINISTRAR AGENDAMENTOS</a>
        <a href="view/brinquedo.php">ADMINISTRAR BRINQUEDOS</a>
        <a href="view/cliente.php">ADMINISTRAR CLIENTES</a>
        <a href="view/ag_prod_cliente.php">TODOS OS AGENDAMENTOS REALIZADOS</a>
    </div>
</body>
</html>
