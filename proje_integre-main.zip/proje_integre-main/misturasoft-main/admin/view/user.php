<?php
include("../control/conexao.php");

$sql = "SELECT id_usuario, nome, email FROM usuario";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Usuários</title>
    <style>
        /* Estilo para a página */
        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background-color: #f3f3f3;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        /* Caixa central */
        .container {
            background-color: #65b032;
            padding: 20px 40px;
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
            text-align: center;
            color: white;
            max-width: 600px;
            overflow-x: auto;
        }

        /* Título */
        .container h1 {
            font-size: 20px;
            margin-bottom: 20px;
        }

        /* Tabela */
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }

        th, td {
            border: 1px solid white;
            padding: 8px;
            text-align: center;
            color: white;
        }

        th {
            background-color: #4a8b28;
        }

        td a {
            color: white;
            text-decoration: none;
            font-weight: bold;
        }

        td a:hover {
            text-decoration: underline;
        }

        /* Botão de sair */
        .exit-button {
            display: inline-block;
            padding: 10px 20px;
            background-color: #d9534f;
            color: white;
            font-size: 16px;
            text-decoration: none;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        .exit-button:hover {
            background-color: #c9302c;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>LISTA DE USUÁRIOS</h1>
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>NOME</th>
                    <th>EMAIL</th>
                    <th>EDITAR</th>
                    <th>EXCLUIR</th>
                </tr>
            </thead>
            <tbody>
                <?php
                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        echo "<tr>";
                        echo "<td>" . htmlspecialchars($row['id_usuario']) . "</td>";
                        echo "<td>" . htmlspecialchars($row['nome']) . "</td>";
                        echo "<td>" . htmlspecialchars($row['email']) . "</td>";
                        echo "<td><a href='../model/user/editarUser.php?id=" . $row['id_usuario'] . "'>Editar</a></td>";
                        echo "<td><a href='../model/user/excluirUser.php?id=" . $row['id_usuario'] . "'>Excluir</a></td>";
                        echo "</tr>";
                    }
                } else {
                    echo "<tr><td colspan='5'>Nenhum usuário encontrado.</td></tr>";
                }
                ?>
            </tbody>
        </table>
        <a href="/proje_integre-main/misturasoft-main/admin/index.php" class="exit-button">SAIR</a>
    </div>
</body>
</html>

