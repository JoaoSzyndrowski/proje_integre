<?php
include("../control/conexao.php");

// Configuração de paginação
$limite = 5; // Número de registros por página
$pagina = isset($_GET['pagina']) ? (int)$_GET['pagina'] : 1;
$offset = ($pagina - 1) * $limite;

// Consulta com limite
$sql = "SELECT * FROM agendamento LIMIT $offset, $limite";
$result = $conn->query($sql);

// Consulta total de registros
$total_sql = "SELECT COUNT(*) as total FROM agendamento";
$total_result = $conn->query($total_sql);
$total_row = $total_result->fetch_assoc();
$total_registros = $total_row['total'];
$total_paginas = ceil($total_registros / $limite);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Agendamentos</title>
    <style>
        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background-color: #f3f3f3;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
        }

        .container {
            background-color: #65b032;
            padding: 20px 40px;
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
            text-align: center;
            color: white;
            width: 800px;
        }

        .container h1 {
            font-size: 20px;
            margin-bottom: 20px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }

        th, td {
            border: 1px solid white;
            padding: 8px;
            text-align: center;
            color: white;
        }

        th {
            background-color: #4a8b28;
        }

        td a {
            color: white;
            text-decoration: none;
            font-weight: bold;
        }

        td a:hover {
            text-decoration: underline;
        }

        .pagination {
            margin: 20px 0;
        }

        .pagination a {
            margin: 0 5px;
            padding: 5px 10px;
            background-color: #4a8b28;
            color: white;
            text-decoration: none;
            border-radius: 3px;
        }

        .pagination a:hover {
            background-color: #3c7123;
        }

        .pagination .active {
            font-weight: bold;
            background-color: #3c7123;
        }

        .exit-button {
            display: inline-block;
            padding: 10px 20px;
            background-color: #d9534f;
            color: white;
            font-size: 16px;
            text-decoration: none;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        .exit-button:hover {
            background-color: #c9302c;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>LISTA DE AGENDAMENTOS</h1>
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>DATA</th>
                    <th>PRODUTO</th>
                    <th>HORA INÍCIO</th>
                    <th>HORA FIM</th>
                    <th>CLIENTE</th>
                    <th>STATUS</th>
                    <th>EDITAR</th>
                    <th>EXCLUIR</th>
                </tr>
            </thead>
            <tbody>
                <?php
                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        echo "<tr>";
                        echo "<td>" . htmlspecialchars($row['id_agenda']) . "</td>";
                        echo "<td>" . htmlspecialchars($row['data']) . "</td>";
                        echo "<td>" . htmlspecialchars($row['id_produto']) . "</td>";
                        echo "<td>" . htmlspecialchars($row['horainicio']) . "</td>";
                        echo "<td>" . htmlspecialchars($row['horafim']) . "</td>";
                        echo "<td>" . htmlspecialchars($row['id_cliente']) . "</td>";
                        echo "<td>" . htmlspecialchars($row['sts']) . "</td>";
                        echo "<td><a href='../model/agendamento/editarAg.php?id=" . $row['id_agenda'] . "'>Editar</a></td>";
                        echo "<td><a href='../model/agendamento/excluirAg.php?id=" . $row['id_agenda'] . "'>Excluir</a></td>";
                        echo "</tr>";
                    }
                } else {
                    echo "<tr><td colspan='9'>Nenhum agendamento encontrado.</td></tr>";
                }
                ?>
            </tbody>
        </table>

        <!-- Paginação -->
        <div class="pagination">
            <?php
            for ($i = 1; $i <= $total_paginas; $i++) {
                if ($i == $pagina) {
                    echo "<span class='active'>$i</span>";
                } else {
                    echo "<a href='?pagina=$i'>$i</a>";
                }
            }
            ?>
        </div>

        <!-- Botão de saída -->
        <a href="/proje_integre-main/misturasoft-main/admin/index.php" class="exit-button">SAIR</a>
    </div>
</body>
</html>

