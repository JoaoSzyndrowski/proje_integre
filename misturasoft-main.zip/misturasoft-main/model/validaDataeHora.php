<?php
include("../control/conexao.php");

$id_produto = $_POST["id_produto"];
var_dump($id_produto);
$dataAluguel=$_POST['diaAluguel'];
$horaInicio = $_POST['horaInicio'];
$horaFim = $_POST['horaFim'];

$sql = "SELECT * FROM agendamento WHERE data = '$dataAluguel' AND id_produto = $id_produto";
$result = $conn->query($sql);
$row = $result->fetch_assoc();


if(isset($row['data'])){
    echo 'nao esta disponivel';
}else{
    echo 'esta disponiiu';
    if($horaInicio == $row['horaInicio']){
        echo 'o horario de inicio ja foi selecionado';
    }else{
        echo $horaInicio(true);
    }
    if($horaFim == $row['horaFim']){
        echo "hora fim ja foi selecionada para essa data";
    }
}

?>