<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Brinquedos - MisturaSoft</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: Arial, sans-serif;
        }

        body {
            background-color: #f2f2f2;
            color: #333;
        }

        .container {
            width: 90%;
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }

        header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 20px 0;
        }

        nav ul {
            list-style: none;
            display: flex;
            gap: 20px;
        }

        nav a {
            text-decoration: none;
            color: #333;
            font-weight: bold;
        }

        .search-bar {
            display: flex;
            align-items: center;
            gap: 10px;
            margin-top: 20px;
            margin-bottom: 20px;
        }

        .search-bar input {
            padding: 10px;
            font-size: 16px;
            border: 1px solid #ccc;
            border-radius: 5px;
            width: 100%;
            max-width: 400px;
        }

        .search-bar button {
            background-color: #6fae42;
            color: white;
            border: none;
            padding: 10px 20px;
            font-size: 16px;
            cursor: pointer;
            border-radius: 5px;
        }

        .products {
            display: flex;
            flex-direction: column;
            gap: 20px;
        }

        .product-card {
            display: flex;
            align-items: center;
            padding: 20px;
            background-color: #ffffff;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        .product-image {
            width: 100px;
            height: 100px;
            border-radius: 10px;
            overflow: hidden;
            margin-right: 20px;
        }

        .product-image img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .product-info {
            flex: 1;
        }

        .product-info h3 {
            font-size: 18px;
            margin-bottom: 5px;
        }

        .product-info p {
            font-size: 14px;
            color: #666;
            margin-bottom: 10px;
        }

        .product-card button {
            background-color: #6fae42;
            color: white;
            border: none;
            padding: 10px 20px;
            font-size: 16px;
            cursor: pointer;
            border-radius: 5px;
            transition: background-color 0.3s;
        }

        .product-card button:hover {
            background-color: #5b8d36;
        }

        /* Responsividade */
        @media (max-width: 768px) {
            header {
                flex-direction: column;
                text-align: center;
            }

            nav ul {
                flex-direction: column;
                gap: 10px;
            }

            .product-card {
                flex-direction: column;
                align-items: center;
                text-align: center;
            }

            .product-image {
                margin-right: 0;
                margin-bottom: 15px;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <header>
            <div class="logo">
                <img src="/misturasoft-main/imagens/logo.png" alt="" height="100" width="230">
                
            </div>
            <nav>
                <ul>
                    <li><a href="/misturasoft-main/iniciologado.html">Início</a></li>
                    <li><a href="#">Brinquedos</a></li>
                    <li><a href="sobre.php">Sobre nós</a></li>
                </ul>
            </nav>
        </header>
        
        <div class="search-bar">
            <input type="text" placeholder="Pesquisar brinquedo">
            <button>🔍</button>
        </div>

        <h2>Brinquedos</h2>
        
        <div class="products">
            <div class="product-card">
                <div class="product-image">
                    <img src="cama-elastica1.jpg" alt="Cama elástica">
                </div>
                <div class="product-info">
                    <h3>Cama elástica</h3>
                    <p>Tamanho/capacidade</p>
                </div>
                <a href="../view/ag_brinq.php">
                <button>Reservar</button>
                </a>
            </div>
            
            <div class="product-card">
                <div class="product-image">
                    <img src="cama-elastica2.jpg" alt="Cama elástica">
                </div>
                <div class="product-info">
                    <h3>Cama elástica</h3>
                    <p>Tamanho/capacidade</p>
                </div>
                <a href="../view/ag_brinq.php">
                <button>Reservar</button>
                </a>
                
            </div>
            
            <div class="product-card">
                <div class="product-image">
                    <img src="cama-elastica3.jpg" alt="Cama elástica">
                </div>
                <div class="product-info">
                    <h3>Cama elástica</h3>
                    <p>Tamanho/capacidade</p>
                </div>
                <a href="../view/ag_brinq.php">
                <button>Reservar</button>
                </a>
            </div>
        </div>
    </div>
</body>
</html>

